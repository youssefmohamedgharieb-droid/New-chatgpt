SmartCam AI final mobile web build.
Live camera requires HTTPS. Native phone-camera fallback is included.
Three automatic looks: Natural, Detail, Cinematic.
Heavy SR model intentionally omitted because it caused mobile-browser crashes.
